import './App.css';
import Calculator from './components/calculator';

function App() {
  return (
    <div className="App">
      <Calculator/>
    </div>
  );
}

export default App;
